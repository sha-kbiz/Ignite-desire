class CurrentUser {
  final String uid;
  CurrentUser({required this.uid});
}
